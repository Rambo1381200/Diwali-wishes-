import React from 'react'

const Chakra = () => {
  return (
    <div>Chakra</div>
  )
}

export default Chakra