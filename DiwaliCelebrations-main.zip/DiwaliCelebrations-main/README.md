# 💥 Diwali wishes 2022

![image](https://user-images.githubusercontent.com/56472120/197407232-6dc57fbe-a0a1-407c-9de0-a2cc7f2a34cd.png)
